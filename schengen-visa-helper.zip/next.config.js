// Next.js config placeholder
